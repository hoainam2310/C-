﻿
namespace baitapbuoi7
{
    partial class f_game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(f_game));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_step = new System.Windows.Forms.Label();
            this.p_start = new System.Windows.Forms.Panel();
            this.l_start = new System.Windows.Forms.Label();
            this.picb_start = new System.Windows.Forms.PictureBox();
            this.picb_img_example1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.picb_img_example2 = new System.Windows.Forms.PictureBox();
            this.picb_img_example3 = new System.Windows.Forms.PictureBox();
            this.picb_img_example4 = new System.Windows.Forms.PictureBox();
            this.picb_img_example5 = new System.Windows.Forms.PictureBox();
            this.picb_img_example6 = new System.Windows.Forms.PictureBox();
            this.picb_img_example7 = new System.Windows.Forms.PictureBox();
            this.picb_img_example8 = new System.Windows.Forms.PictureBox();
            this.picb_img_example9 = new System.Windows.Forms.PictureBox();
            this.picb_img_example10 = new System.Windows.Forms.PictureBox();
            this.p_start.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb_start)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example10)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(520, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Example";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(39, 492);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 32);
            this.label2.TabIndex = 1;
            this.label2.Tag = " ";
            this.label2.Text = "Số bước đi :";
            // 
            // lb_step
            // 
            this.lb_step.AutoSize = true;
            this.lb_step.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_step.ForeColor = System.Drawing.Color.White;
            this.lb_step.Location = new System.Drawing.Point(199, 492);
            this.lb_step.Name = "lb_step";
            this.lb_step.Size = new System.Drawing.Size(31, 32);
            this.lb_step.TabIndex = 2;
            this.lb_step.Tag = " ";
            this.lb_step.Text = "0";
            // 
            // p_start
            // 
            this.p_start.BackColor = System.Drawing.Color.DimGray;
            this.p_start.Controls.Add(this.l_start);
            this.p_start.Controls.Add(this.picb_start);
            this.p_start.Location = new System.Drawing.Point(403, 482);
            this.p_start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.p_start.Name = "p_start";
            this.p_start.Size = new System.Drawing.Size(188, 69);
            this.p_start.TabIndex = 5;
            this.p_start.Click += new System.EventHandler(this.p_start_Click);
            // 
            // l_start
            // 
            this.l_start.AutoSize = true;
            this.l_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l_start.ForeColor = System.Drawing.Color.White;
            this.l_start.Location = new System.Drawing.Point(73, 18);
            this.l_start.Name = "l_start";
            this.l_start.Size = new System.Drawing.Size(75, 32);
            this.l_start.TabIndex = 7;
            this.l_start.Tag = " ";
            this.l_start.Text = "Start";
            this.l_start.Click += new System.EventHandler(this.l_start_Click);
            // 
            // picb_start
            // 
            this.picb_start.Image = global::baitapbuoi7.Properties.Resources._25263_here_orange_start_icon;
            this.picb_start.Location = new System.Drawing.Point(0, 2);
            this.picb_start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_start.Name = "picb_start";
            this.picb_start.Size = new System.Drawing.Size(67, 66);
            this.picb_start.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_start.TabIndex = 6;
            this.picb_start.TabStop = false;
            this.picb_start.Click += new System.EventHandler(this.picb_start_Click);
            // 
            // picb_img_example1
            // 
            this.picb_img_example1.Image = global::baitapbuoi7.Properties.Resources.M11;
            this.picb_img_example1.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example1.Name = "picb_img_example1";
            this.picb_img_example1.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example1.TabIndex = 4;
            this.picb_img_example1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox4.Location = new System.Drawing.Point(491, 2);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(11, 34);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox5.Location = new System.Drawing.Point(491, 42);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(11, 34);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox6.Location = new System.Drawing.Point(491, 82);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(11, 34);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox7.Location = new System.Drawing.Point(491, 122);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(11, 34);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 9;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox8.Location = new System.Drawing.Point(491, 162);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(11, 34);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox9.Location = new System.Drawing.Point(491, 202);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(11, 34);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 11;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox10.Location = new System.Drawing.Point(491, 242);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(11, 34);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 12;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox11.Location = new System.Drawing.Point(491, 282);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(11, 34);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 13;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox12.Location = new System.Drawing.Point(491, 322);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(11, 34);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 14;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox13.Location = new System.Drawing.Point(491, 362);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(11, 34);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 15;
            this.pictureBox13.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox14.Location = new System.Drawing.Point(491, 402);
            this.pictureBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(11, 34);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 16;
            this.pictureBox14.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::baitapbuoi7.Properties.Resources.Capture;
            this.pictureBox15.Location = new System.Drawing.Point(491, 442);
            this.pictureBox15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(11, 34);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 17;
            this.pictureBox15.TabStop = false;
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.White;
            this.btn_7.Enabled = false;
            this.btn_7.Location = new System.Drawing.Point(23, 63);
            this.btn_7.Margin = new System.Windows.Forms.Padding(4);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(141, 123);
            this.btn_7.TabIndex = 18;
            this.btn_7.UseVisualStyleBackColor = false;
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.Blue;
            this.btn_4.Enabled = false;
            this.btn_4.Location = new System.Drawing.Point(23, 193);
            this.btn_4.Margin = new System.Windows.Forms.Padding(4);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(141, 123);
            this.btn_4.TabIndex = 19;
            this.btn_4.UseVisualStyleBackColor = false;
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.Green;
            this.btn_1.Enabled = false;
            this.btn_1.Location = new System.Drawing.Point(23, 324);
            this.btn_1.Margin = new System.Windows.Forms.Padding(4);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(141, 123);
            this.btn_1.TabIndex = 20;
            this.btn_1.UseVisualStyleBackColor = false;
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.Blue;
            this.btn_2.Enabled = false;
            this.btn_2.Location = new System.Drawing.Point(172, 322);
            this.btn_2.Margin = new System.Windows.Forms.Padding(4);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(141, 123);
            this.btn_2.TabIndex = 21;
            this.btn_2.UseVisualStyleBackColor = false;
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.Green;
            this.btn_5.Enabled = false;
            this.btn_5.Location = new System.Drawing.Point(172, 193);
            this.btn_5.Margin = new System.Windows.Forms.Padding(4);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(141, 123);
            this.btn_5.TabIndex = 22;
            this.btn_5.UseVisualStyleBackColor = false;
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.Color.Red;
            this.btn_8.Enabled = false;
            this.btn_8.Location = new System.Drawing.Point(172, 63);
            this.btn_8.Margin = new System.Windows.Forms.Padding(4);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(141, 123);
            this.btn_8.TabIndex = 23;
            this.btn_8.UseVisualStyleBackColor = false;
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.Green;
            this.btn_9.Enabled = false;
            this.btn_9.Location = new System.Drawing.Point(321, 63);
            this.btn_9.Margin = new System.Windows.Forms.Padding(4);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(141, 123);
            this.btn_9.TabIndex = 24;
            this.btn_9.UseVisualStyleBackColor = false;
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.Blue;
            this.btn_6.Enabled = false;
            this.btn_6.Location = new System.Drawing.Point(321, 193);
            this.btn_6.Margin = new System.Windows.Forms.Padding(4);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(141, 123);
            this.btn_6.TabIndex = 25;
            this.btn_6.UseVisualStyleBackColor = false;
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.Red;
            this.btn_3.Enabled = false;
            this.btn_3.Location = new System.Drawing.Point(321, 324);
            this.btn_3.Margin = new System.Windows.Forms.Padding(4);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(141, 123);
            this.btn_3.TabIndex = 26;
            this.btn_3.UseVisualStyleBackColor = false;
            // 
            // picb_img_example2
            // 
            this.picb_img_example2.Image = global::baitapbuoi7.Properties.Resources.M12;
            this.picb_img_example2.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example2.Name = "picb_img_example2";
            this.picb_img_example2.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example2.TabIndex = 27;
            this.picb_img_example2.TabStop = false;
            // 
            // picb_img_example3
            // 
            this.picb_img_example3.Image = global::baitapbuoi7.Properties.Resources.M13;
            this.picb_img_example3.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example3.Name = "picb_img_example3";
            this.picb_img_example3.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example3.TabIndex = 28;
            this.picb_img_example3.TabStop = false;
            // 
            // picb_img_example4
            // 
            this.picb_img_example4.Image = global::baitapbuoi7.Properties.Resources.M14;
            this.picb_img_example4.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example4.Name = "picb_img_example4";
            this.picb_img_example4.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example4.TabIndex = 29;
            this.picb_img_example4.TabStop = false;
            // 
            // picb_img_example5
            // 
            this.picb_img_example5.Image = global::baitapbuoi7.Properties.Resources.M15;
            this.picb_img_example5.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example5.Name = "picb_img_example5";
            this.picb_img_example5.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example5.TabIndex = 30;
            this.picb_img_example5.TabStop = false;
            // 
            // picb_img_example6
            // 
            this.picb_img_example6.Image = global::baitapbuoi7.Properties.Resources.M16;
            this.picb_img_example6.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example6.Name = "picb_img_example6";
            this.picb_img_example6.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example6.TabIndex = 31;
            this.picb_img_example6.TabStop = false;
            // 
            // picb_img_example7
            // 
            this.picb_img_example7.Image = global::baitapbuoi7.Properties.Resources.M17;
            this.picb_img_example7.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example7.Name = "picb_img_example7";
            this.picb_img_example7.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example7.TabIndex = 32;
            this.picb_img_example7.TabStop = false;
            // 
            // picb_img_example8
            // 
            this.picb_img_example8.Image = global::baitapbuoi7.Properties.Resources.M18;
            this.picb_img_example8.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example8.Name = "picb_img_example8";
            this.picb_img_example8.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example8.TabIndex = 33;
            this.picb_img_example8.TabStop = false;
            // 
            // picb_img_example9
            // 
            this.picb_img_example9.Image = global::baitapbuoi7.Properties.Resources.M19;
            this.picb_img_example9.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example9.Name = "picb_img_example9";
            this.picb_img_example9.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example9.TabIndex = 34;
            this.picb_img_example9.TabStop = false;
            // 
            // picb_img_example10
            // 
            this.picb_img_example10.Image = global::baitapbuoi7.Properties.Resources.M20;
            this.picb_img_example10.Location = new System.Drawing.Point(525, 63);
            this.picb_img_example10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.picb_img_example10.Name = "picb_img_example10";
            this.picb_img_example10.Size = new System.Drawing.Size(445, 379);
            this.picb_img_example10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_img_example10.TabIndex = 35;
            this.picb_img_example10.TabStop = false;
            // 
            // f_game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(995, 580);
            this.Controls.Add(this.picb_img_example10);
            this.Controls.Add(this.picb_img_example9);
            this.Controls.Add(this.picb_img_example8);
            this.Controls.Add(this.picb_img_example7);
            this.Controls.Add(this.picb_img_example6);
            this.Controls.Add(this.picb_img_example5);
            this.Controls.Add(this.picb_img_example4);
            this.Controls.Add(this.picb_img_example3);
            this.Controls.Add(this.picb_img_example2);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_7);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.p_start);
            this.Controls.Add(this.picb_img_example1);
            this.Controls.Add(this.lb_step);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "f_game";
            this.Text = "Game";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.f_game_KeyDown);
            this.p_start.ResumeLayout(false);
            this.p_start.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picb_start)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_img_example10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lb_step;
        private System.Windows.Forms.PictureBox picb_img_example1;
        private System.Windows.Forms.Panel p_start;
        private System.Windows.Forms.Label l_start;
        private System.Windows.Forms.PictureBox picb_start;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.PictureBox picb_img_example2;
        private System.Windows.Forms.PictureBox picb_img_example3;
        private System.Windows.Forms.PictureBox picb_img_example4;
        private System.Windows.Forms.PictureBox picb_img_example5;
        private System.Windows.Forms.PictureBox picb_img_example6;
        private System.Windows.Forms.PictureBox picb_img_example7;
        private System.Windows.Forms.PictureBox picb_img_example8;
        private System.Windows.Forms.PictureBox picb_img_example9;
        private System.Windows.Forms.PictureBox picb_img_example10;
    }
}

